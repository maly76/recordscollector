package com.example.leistungssammler.model

class Student (_name: String,
               _matrikelNummer: Int,
               _studiengang: String) {
    val name = _name
    val matrikelNummer = _matrikelNummer
    val studiengang = _studiengang
}